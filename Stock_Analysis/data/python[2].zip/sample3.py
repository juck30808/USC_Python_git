x = int(input('please input x:'))

if x>10:
 print('x>10')
else:
 print('x <=10')
