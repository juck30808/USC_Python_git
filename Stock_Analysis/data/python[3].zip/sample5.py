y = int(input('please input x:'))

x=0
num=0
while x <=y:
 num+=x
 x+=1

print('sum :',num)
