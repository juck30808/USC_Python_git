from function import GetI020
import sys

Data = GetI020()

date_list = [ i[0] for i in Data ]
date_list = sorted(list(set(date_list)))

total_profit = 0

for date in date_list:
  I020 = [ i for i in Data if i[0] == date ]
  
  # 取出進場前時間段
  I020_1 = [ int(i[3]) for i in I020 if int(i[1])>=8450000 and int(i[1])<=9000000 ]
  # 取出最高價
  max_price = max(I020_1)
  
  # 進場判斷
  I020_2 = [ i for i in I020 if int(i[1])>=9000000 and int(i[1])<=11000000 ]
   
  index = 0 
  # 判斷是否當前價突破 先前最高價
  for i in range(len(I020_2)):
    time = int(I020_2[i][1])
    price = int(I020_2[i][3])
    if price > max_price:
      index = 1
      OrderTime = time
      OrderPrice = price
      break
  
  # 若當天沒進場，則直接跳下一天
  if index == 0 :
    print(date + ' no Trade')
    continue
  
  # 出場判斷
  I020_3 = [ i for i in I020 if int(i[1])>=OrderTime and int(i[1])<=11000000 ]

  for i in range(len(I020_3)):
    time = int(I020_3[i][1])
    price = int(I020_3[i][3])
    if price >= OrderPrice +20:
      index = 0
      CoverTime = time
      CoverPrice = price
      break
    elif price <= OrderPrice -20:
      index = 0
      CoverTime = time
      CoverPrice = price
      break
    elif i == len(I020_3)-1:
      index = 0
      CoverTime = time
      CoverPrice = price
      
  profit = CoverPrice-OrderPrice
  total_profit += profit 
  print(date,'Buy',OrderTime,'OrderPrice:',OrderPrice,CoverTime,'CoverPrice:',CoverPrice,'profit',profit)

print('Total Profit:' ,total_profit )


