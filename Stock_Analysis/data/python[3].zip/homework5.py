from function import GetI020
import sys

Data = GetI020()

date_list = [ i[0] for i in Data ]
date_list = sorted(list(set(date_list)))

total_profit = 0
profit_list = []
B_profit_list =[]
S_profit_list =[]

for date in date_list:
  I020 = [ i for i in Data if i[0] == date ]
  
  # 取出進場前時間段
  I020_1 = [ int(i[3]) for i in I020 if int(i[1])>=8450000 and int(i[1])<=9000000 ]
  # 取出最高 最低價
  max_price = max(I020_1)
  min_price = min(I020_1)
  spread = max_price-min_price
  
  # 進場判斷
  I020_2 = [ i for i in I020 if int(i[1])>=9000000 and int(i[1])<=11000000 ]
   
  index = 0 
  # 判斷是否當前價突破 先前最高價
  for i in range(len(I020_2)):
    time = int(I020_2[i][1])
    price = int(I020_2[i][3])
    if price > max_price+spread*0.2:
      index = 1
      OrderTime = time
      OrderPrice = price
      break
    elif price < min_price-spread*0.2:
      index = -1
      OrderTime = time
      OrderPrice = price
      break
  
  # 若當天沒進場，則直接跳下一天
  if index == 0 :
    print(date + ' no Trade')
    continue
  
  # 出場判斷
  
  I020_beforeOrder = [ int(i[3]) for i in I020 if int(i[1])<=OrderTime ]
  max_price = max(I020_beforeOrder)
  min_price = min(I020_beforeOrder)

  stoploss = 20 
  
  I020_3 = [ i for i in I020 if int(i[1])>=OrderTime and int(i[1])<=11000000 ]

  if index==1:
    # 建立移動停損點
    max_point = OrderPrice 
  
    for i in range(len(I020_3)):
      time = int(I020_3[i][1])
      price = int(I020_3[i][3])
      if price >= max_point:
        max_point = price 
      if price >= OrderPrice +50:
        index = 0
        CoverTime = time
        CoverPrice = price
        break
      elif price <= max_point - stoploss:
        index = 0
        CoverTime = time
        CoverPrice = price
        break
      elif price <= min_price:
        index = 0
        CoverTime = time
        CoverPrice = price
        break
      elif i == len(I020_3)-1:
        index = 0
        CoverTime = time
        CoverPrice = price
        
    profit = CoverPrice-OrderPrice
    total_profit += profit 
    B_profit_list.append(profit)
    print(date,'Buy',OrderTime,'OrderPrice:',OrderPrice,CoverTime,'CoverPrice:',CoverPrice,'profit',profit)
  elif index==-1:
    min_point = OrderPrice
  
    if price <= min_point:
      min_point=price
    
    for i in range(len(I020_3)):
      time = int(I020_3[i][1])
      price = int(I020_3[i][3])
      if price <= OrderPrice -50:
        index = 0
        CoverTime = time
        CoverPrice = price
        break
      elif price >= min_point + stoploss:
        index = 0
        CoverTime = time
        CoverPrice = price
        break
      elif price >= max_price:
        index = 0
        CoverTime = time
        CoverPrice = price
        break
      elif i == len(I020_3)-1:
        index = 0
        CoverTime = time
        CoverPrice = price
        
    profit = OrderPrice-CoverPrice
    total_profit += profit 
    S_profit_list.append(profit)
    print(date,'Sell',OrderTime,'OrderPrice:',OrderPrice,CoverTime,'CoverPrice:',CoverPrice,'profit',profit)

  profit_list.append(profit)
    

# 計算最大連續虧損
max_loss=0
now_loss=0

for i in profit_list:
  if i>0:
    now_loss = 0
  elif i<=0:
    now_loss +=i
    if max_loss>now_loss:
      max_loss=now_loss

print('Total Profit:' ,total_profit ,' Max Loss:',max_loss)


print('Win Ratio:',len([ i for i in profit_list if i > 0 ])/len(profit_list))
print('Buy Win Ratio:',len([ i for i in B_profit_list if i > 0 ])/len(B_profit_list))
print('Sell Win Ratio:',len([ i for i in S_profit_list if i > 0 ])/len(S_profit_list))