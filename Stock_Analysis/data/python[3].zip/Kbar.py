from function import GetI020
import datetime
import sys

Data = GetI020()
date_list = [ i[0] for i in Data ]
date_list = sorted(list(set(date_list)))

for date in date_list:
  I020 = [ i for i in Data if i[0] == date ]
  
  starttime = datetime.datetime.strptime('08450000','%H%M%S%f')
  cycle = datetime.timedelta(0,60)
  KBar = []
  
  # 計算K棒
  for i in I020:
    time = datetime.datetime.strptime(i[1],'%H%M%S%f')
    price = int(i[3])
    #print(len(KBar))
    if len(KBar)==0:
      #KBar += [[starttime,price,price,price,price]]
      KBar.append([starttime,price,price,price,price])
    else:
      # 判斷換分鐘
      if time > starttime + cycle:
        starttime += cycle
        KBar.append([starttime,price,price,price,price])
      # 如果沒換分鐘
      else :
        if price > KBar[-1][2]:
          KBar[-1][2] = price
        elif price < KBar[-1][3]:
          KBar[-1][3] = price
        KBar[-1][4] = price

  # K棒回測      
  up_flag = 0
  index = 0
  start_price = 0
  for i in KBar:
    open_p = i[1]
    close_p = i[4]
    if close_p > open_p:
      up_flag += 1
      if up_flag == 1:
        start_price = open_p
    elif close_p <= open_p:
      up_flag = 0
      
    # 判斷是否為連三漲 進場
    if up_flag == 3 and index == 0 :
      index = 1
      spread = (close_p - start_price)
      OrderTime = i[0].strftime("%H%M%S")
      OrderPrice = close_p
    
    # 判斷出場
    if index == 1:
      # 停利出場
      if close_p > OrderPrice + spread :
        index = 0 
        CoverTime = i[0].strftime("%H%M%S")
        CoverPrice = close_p
        break
      # 停損出場
      elif close_p < OrderPrice - spread/2:
        index = 0 
        CoverTime = i[0].strftime("%H%M%S")
        CoverPrice = close_p
        break
      if i[0].strftime("%H%M%S")=="134500":
        index = 0 
        CoverTime = i[0].strftime("%H%M%S")
        CoverPrice = close_p
        break
  print(date,'B',OrderTime,OrderPrice,CoverTime,CoverPrice,"Profit:",CoverPrice-OrderPrice)
