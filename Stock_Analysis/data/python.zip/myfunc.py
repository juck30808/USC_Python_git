def mysum(n):
 num=0
 for i in range(n+1):
  num+=i
 return num
