a = input('please input :')

print(a)