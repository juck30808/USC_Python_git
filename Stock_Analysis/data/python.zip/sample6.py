import random
x = int(random.random()*100)

while 1:
 y = int(input('please input (1-100):'))
 if x == y:
  print('boom!!!')
  break
 else:
  if  y<x:
   print('higher') 
  elif  y>x:
   print('lower!')
