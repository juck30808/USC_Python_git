import tailer

def GetMatch(date):
  return tailer.follow(open('C:/data/'+date+'_MicroPlay_Match.txt'),0)
  
def GetOrder(date):
  return tailer.follow(open('C:/data/'+date+'_MicroPlay_Commission.txt'),0)
  
def GetUpDn5(date):
  return tailer.follow(open('C:/data/'+date+'_MicroPlay_UpDn5.txt'),0)