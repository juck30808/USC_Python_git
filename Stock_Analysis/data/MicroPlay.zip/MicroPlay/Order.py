import subprocess

execpath='C:/OrderCmd/'
def OrderMKT(prod,bs,qty):
  OrderNo=subprocess.check_output([execpath+"Test_Order.exe",prod,bs,"0",qty,"MKT","IOC","0"]).decode('big5').strip('\r\n')
  OrderAcc=subprocess.check_output([execpath+"Test_GetAccount.exe",OrderNo]).decode('big5').strip('\r\n')
  return OrderAcc.split(',')