import GetData
import Order
import datetime

date='20181128'
prod='TXFL8'

StartTime=datetime.datetime.strptime('08:50:00.00','%H:%M:%S.%f')
EndTime=datetime.datetime.strptime('09:00:00.00','%H:%M:%S.%f')

# 進場
for i in GetData.GetMatch(date):
  MatchData = i.split(',')
  time = datetime.datetime.strptime(MatchData[0],'%H:%M:%S.%f')
  if time > StartTime:
    OrderInfo=Order.OrderMKT(prod,'B','1')
    OrderTime=OrderInfo[4]
    OrderPrice=OrderInfo[5]
    print(OrderTime,OrderPrice)
    break
    
for i in GetData.GetMatch(date):
  MatchData = i.split(',')
  time = datetime.datetime.strptime(MatchData[0],'%H:%M:%S.%f')
  if time > EndTime:
    CoverInfo=Order.OrderMKT(prod,'S','1')
    CoverTime=CoverInfo[4]
    CoverPrice=CoverInfo[5]
    print(CoverTime,CoverPrice)
    break
    
    