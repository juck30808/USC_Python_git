import tailer

lastdata=''

while True:
  Data=tailer.tail(open('C:/data/20181128_MicroPlay_Match.txt'),3)[-2]
  if Data != lastdata:
    print(Data)
  lastdata=Data
  
  