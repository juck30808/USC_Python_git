       dt= new Date();
       document.write(dt.toLocaleString());
